from flask import Blueprint, request, jsonify
from services.leads_service import (
    create_lead, 
    get_leads_dashboard_stats, 
    get_all_leads_service,
    update_lead_service,
    add_lead_note_service,
    get_lead_activities_service,
    get_lead_statuses,
    get_lead_sources,
    update_lead_status_service,
    get_follow_up_leads_service,
    get_pipeline_stages_service,
    advance_lead_stage_service,
    get_activity_types_service
)
from flask_jwt_extended import get_jwt_identity, jwt_required, get_jwt
from services.base_service import BaseService
from models.employee import Employee

leads_bp = Blueprint('leads', __name__)

@leads_bp.route('/leads/add', methods=['POST'])
@jwt_required()  
def add_lead():
    data = request.json
    emp_id = get_jwt_identity() 
    result, status_code = create_lead(data, emp_id)
    return jsonify(result), status_code

@leads_bp.route('/leads/activities/add', methods=['POST'])
@jwt_required()
def add_note():
    data = request.json
    current_emp_id = get_jwt_identity()
    
    # Validate input
    if not data.get('lead_id'):
        return jsonify({"error": "lead_id is required"}), 400
        
    result, status_code = add_lead_note_service(
        lead_id=data['lead_id'],
        emp_id=current_emp_id,
        details=data.get('details', 'No remarks provided.'),
        activity_type_name=data.get('activity_type_name', 'Note Added')
    )
    return jsonify(result), status_code

@leads_bp.route('/leads/update/<int:id>', methods=['PUT'])
@jwt_required()
def update_lead(id):
    data = request.json
    current_emp_id = get_jwt_identity()
    result, status_code = update_lead_service(id, data, current_emp_id)
    return jsonify(result), status_code

@leads_bp.route('/leads/<int:id>/activities', methods=['GET'])
@jwt_required()
def get_lead_activities(id):
    result, status_code = get_lead_activities_service(id)
    return jsonify(result), status_code

@leads_bp.route('/leads/get-leads-byEmplId', methods=['GET'])
@jwt_required()
def get_lead_by_employee_id():
    emp_id = get_jwt_identity() 
    result, status_code=get_leads_dashboard_stats(emp_id)
    return jsonify(result),status_code

@leads_bp.route('/leads/getall', methods=['GET'])
@jwt_required()
def get_all_leads():
    try:
        claims = get_jwt()
        if claims.get("user_type") != "EMPLOYEE":
            return BaseService.create_response(message="Access denied.", status="error", code=403)

        user_id = get_jwt_identity()
        user = Employee.query.get(user_id)
        
        if not user:
            return BaseService.create_response(message="User not found", status="error", code=404)
        data = get_all_leads_service()
        return BaseService.create_response(data=data, message="All leads fetched successfully")
    except Exception as e:
        return BaseService.create_response(message=str(e), status="error", code=500)

@leads_bp.route('/leads/statuses', methods=['GET'])
@jwt_required()
def get_statuses():
    result, status_code = get_lead_statuses()
    return jsonify(result), status_code

@leads_bp.route('/leads/sources', methods=['GET'])
@jwt_required()
def get_sources():
    result, status_code = get_lead_sources()
    return jsonify(result), status_code

@leads_bp.route('/leads/update-status/<int:id>', methods=['PATCH', 'PUT'])
@jwt_required()
def update_lead_status(id):
    data = request.json
    current_emp_id = get_jwt_identity()
    status_id = data.get('status_id')
    
    if not status_id:
        return jsonify({"error": "status_id is required"}), 400
        
    result, status_code = update_lead_status_service(id, status_id, current_emp_id)
    return jsonify(result), status_code

@leads_bp.route('/leads/follow-ups', methods=['GET'])
@jwt_required()
def get_follow_up_leads():
    try:
        # Get emp_id to filter leads specifically for the logged-in employee 
        emp_id = get_jwt_identity()
        data = get_follow_up_leads_service(emp_id=emp_id)
        return BaseService.create_response(data=data, message="Follow-up leads fetched successfully")
    except Exception as e:
        return BaseService.create_response(message=str(e), status="error", code=500)

@leads_bp.route('/leads/follow-ups/all', methods=['GET'])
@jwt_required()
def get_all_follow_up_leads():
    try:
        # Check permissions similarly to get_all_leads
        claims = get_jwt()
        if claims.get("user_type") != "EMPLOYEE":
            return BaseService.create_response(message="Access denied.", status="error", code=403)
            
        data = get_follow_up_leads_service(emp_id=None)
        return BaseService.create_response(data=data, message="All follow-up leads fetched successfully")
    except Exception as e:
        return BaseService.create_response(message=str(e), status="error", code=500)

@leads_bp.route('/leads/pipeline-stages', methods=['GET'])
@jwt_required()
def get_pipeline_stages():
    result, status_code = get_pipeline_stages_service()
    return jsonify(result), status_code

@leads_bp.route('/leads/<int:id>/advance-stage', methods=['PATCH', 'PUT'])
@jwt_required()
def advance_lead_stage(id):
    data = request.json
    current_emp_id = get_jwt_identity()
    stage_id = data.get('stage_id')
    
    if not stage_id:
        return jsonify({"error": "stage_id is required"}), 400
        
    result, status_code = advance_lead_stage_service(id, stage_id, current_emp_id)
    return jsonify(result), status_code

@leads_bp.route('/leads/activity-types', methods=['GET'])
@jwt_required()
def get_activity_types():
    result, status_code = get_activity_types_service()
    return jsonify(result), status_code
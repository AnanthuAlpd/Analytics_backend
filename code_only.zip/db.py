# from flask_mysqldb import MySQL
# from flask_sqlalchemy import SQLAlchemy
# import pymysql
# pymysql.install_as_MySQLdb()

# mysql = MySQL()
# db = SQLAlchemy()

# def init_db(app):
#     app.config['MYSQL_HOST'] = 'localhost'
#     app.config['MYSQL_USER'] = 'root'
#     app.config['MYSQL_PASSWORD'] = 'Data@123'
#     app.config['MYSQL_DB'] = 'prabha'
#     app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
#     mysql.init_app(app)

#   # SQLAlchemy (ORM)
#     app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:Data%40123@localhost/prabha'
#     app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
#     db.init_app(app)



import pymysql
pymysql.install_as_MySQLdb()

from flask_sqlalchemy import SQLAlchemy
from urllib.parse import quote_plus
import os

db = SQLAlchemy()

def get_db_config():
    return {
        'host': os.environ.get('DB_HOST', 'localhost'),
        'user': os.environ.get('DB_USER', 'root'),
        'password': os.environ.get('DB_PASSWORD', 'Data@123'),
        'database': os.environ.get('DB_NAME', 'prabha'),
        'cursorclass': pymysql.cursors.DictCursor
    }

def get_db():
    config = get_db_config()
    return pymysql.connect(**config)

def init_db(app):
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:Data%40123@localhost/prabha'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    db.init_app(app)
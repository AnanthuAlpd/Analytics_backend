# models/clients.py

from datetime import datetime
from db import db
from werkzeug.security import generate_password_hash, check_password_hash


class Client(db.Model):
    __tablename__ = 'clients'

    client_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(15))
    ref_emp_id = db.Column(db.Integer,db.ForeignKey('employees.id'))  # FK to employees.id (optional)
    service_id = db.Column(db.Integer, db.ForeignKey('services.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    is_deleted = db.Column(db.Boolean, default=False, nullable=False)
    
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))
    role = db.relationship('Role', backref='clients') 
    service = db.relationship('Service', backref='clients')
    ref_emp=db.relationship('Employee', backref="clients")

    def set_password(self, raw_password):
        self.password = generate_password_hash(raw_password)

    def check_password(self, raw_password):
        return check_password_hash(self.password, raw_password)

    def to_dict(self):
        return {
            "client_id": self.client_id,
            "name": self.name,
            "email": self.email,
            "phone": self.phone,
            "ref_emp_id": self.ref_emp_id,
            "service_id":self.service_id,
            "service_name": self.service.name,
            "ref_emp_name":self.ref_emp.name,
            "created_at": self.created_at.isoformat(),
            "updated_at": self.updated_at.isoformat(),
            "roles": [{"id": self.role.id, "name": self.role.name}] if self.role else None
        }

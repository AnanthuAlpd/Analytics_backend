from datetime import datetime, timedelta
from sqlalchemy import func, extract
from db import db
from models.leads import Lead
from models.leads_activity_logs import LeadsActivityLog
from models.leads_status import LeadsStatus
from models.leads_sources import LeadsSource
from models.leads_stage import LeadsStage
from models.leads_stage_actions import LeadsStageAction
from models.leads_activity_type import LeadsActivityType

def create_lead(data, emp_id):
    try:
        # Validation
        required_fields = ['name', 'email', 'lead_cat']
        for field in required_fields:
            if not data.get(field):
                return {"error": f"Field '{field}' is required"}, 400

        lead = Lead(
            emp_id=emp_id,
            name=data.get('name'),
            lead_cat=data.get('lead_cat'),
            email=data.get('email'),
            mob_no=data.get('mob_no'),
            lead_source_id=data.get('lead_source_id'),
            status_id=data.get('status_id'),
            remarks=data.get('remarks')
        )
        
        # New Pipeline Logic Integration for Employee Category
        if lead.lead_cat == 'Employee':
            stage = LeadsStage.query.filter_by(order_no=1).first()
            if stage:
                lead.stage_id = stage.id
                lead.follow_up_date = datetime.now() + timedelta(days=stage.delay_days)
                
        db.session.add(lead)
        db.session.commit()
        
        # Log activity
        if lead.lead_cat == 'Employee':
            log_lead_activity(lead.id, emp_id, 'Lead Created', 'Lead was successfully added and Employee Pipeline initialized.')
        else:
            log_lead_activity(lead.id, emp_id, 'Lead Created', 'Lead was successfully added.')
        
        return {"message": "Lead created successfully", "lead_id": lead.id}, 201

    except Exception as e:
        db.session.rollback()
        return {"error": str(e)}, 500

def get_leads_dashboard_stats(emp_id=None):
    try:
        now = datetime.now()
        current_month = now.month
        previous_month = (now - timedelta(days=30)).month  # Approximation

        # Base query
        base_query = db.session.query(Lead).filter(Lead.emp_id == emp_id)

        # Total leads
        total_client_leads = base_query.filter(Lead.lead_cat == 'Client').count()
        total_employee_leads = base_query.filter(Lead.lead_cat == 'Employee').count()

        # Month-wise leads
        client_current = base_query.filter(
            Lead.lead_cat == 'Client',
            extract('month', Lead.created_at) == current_month
        ).count()

        client_previous = base_query.filter(
            Lead.lead_cat == 'Client',
            extract('month', Lead.created_at) == previous_month
        ).count()

        employee_current = base_query.filter(
            Lead.lead_cat == 'Employee',
            extract('month', Lead.created_at) == current_month
        ).count()

        employee_previous = base_query.filter(
            Lead.lead_cat == 'Employee',
            extract('month', Lead.created_at) == previous_month
        ).count()

        # 🔸 Leads assigned to this employee (emp_id)
        emp_leads = []
        if emp_id:
            emp_leads_query = db.session.query(
                Lead.id,
                Lead.name,
                Lead.email,
                Lead.mob_no,
                Lead.created_at,
                Lead.lead_cat,
                LeadsStatus.status_name
            ).join(LeadsStatus, Lead.status_id == LeadsStatus.id, isouter=True).filter(Lead.emp_id == emp_id).all()

            # Convert to list of dicts
            emp_leads = [
                {
                    "id": lead.id,
                    "name": lead.name,
                    "email": lead.email,
                    "mob_no": lead.mob_no,
                    "created_at": lead.created_at.strftime('%Y-%m-%d'),
                    "lead_cat": lead.lead_cat,
                    "status": lead.status_name
                }
                for lead in emp_leads_query
            ]

        return {
            "total_client_leads": total_client_leads,
            "total_employee_leads": total_employee_leads,
            "client_current": client_current,
            "client_previous": client_previous,
            "employee_current": employee_current,
            "employee_previous": employee_previous,
            "assigned_leads": emp_leads,
            "message": "Dashboard data fetched successfully"
        }, 200

    except Exception as e:
        db.session.rollback()
        return {"error": str(e)}, 500

def get_all_leads_service():
    try:
        leads = Lead.query.all()
        lead_list = [
            {
                "id": lead.id,
                "emp_id": lead.emp_id,
                "emp_name": lead.employee.name if lead.employee else "Unknown",
                "name": lead.name,
                "lead_cat": lead.lead_cat,
                "email": lead.email,
                "mob_no": lead.mob_no,
                "lead_source": lead.source_rel.source_name if lead.source_rel else None,
                "status": lead.status_rel.status_name if lead.status_rel else None,
                "lead_source_id": lead.lead_source_id,
                "status_id": lead.status_id,
                "stage_id": lead.stage_id,
                "stage_name": lead.stage.stage_name if lead.stage else "Unknown",
                "remarks": lead.remarks,
                "created_at": lead.created_at
            }
            for lead in leads
        ]
        return lead_list
    except Exception as e:
        raise Exception(str(e))

def get_follow_up_leads_service(emp_id=None):
    """Fetches all leads that currently have 'Follow-Up' status."""
    try:
        query = db.session.query(Lead).join(LeadsStatus).filter(LeadsStatus.status_name == 'Follow-Up')
        
        # Optional filter by employee if required
        if emp_id:
            query = query.filter(Lead.emp_id == emp_id)
            
        leads = query.all()
        lead_list = [
            {
                "id": lead.id,
                "emp_id": lead.emp_id,
                "emp_name": lead.employee.name if lead.employee else "Unknown",
                "name": lead.name,
                "lead_cat": lead.lead_cat,
                "email": lead.email,
                "mob_no": lead.mob_no,
                "lead_source": lead.source_rel.source_name if lead.source_rel else None,
                "status": lead.status_rel.status_name if lead.status_rel else None,
                "lead_source_id": lead.lead_source_id,
                "status_id": lead.status_id,
                "stage_id": lead.stage_id,
                "stage_name": lead.stage.stage_name if lead.stage else "Unknown",
                "remarks": lead.remarks,
                "created_at": lead.created_at.strftime('%Y-%m-%d %H:%M:%S') if lead.created_at else None,
                "follow_up_date": lead.follow_up_date.strftime('%Y-%m-%d %H:%M:%S') if lead.follow_up_date else None
            }
            for lead in leads
        ]
        return lead_list
    except Exception as e:
        raise Exception(str(e))

def log_lead_activity(lead_id, emp_id, action_type, details, old_val=None, new_val=None):
    """Utility to log lead activities."""
    try:
        activity_record = LeadsActivityType.query.filter_by(name=action_type).first()
        activity_type_id = activity_record.id if activity_record else None

        log = LeadsActivityLog(
            lead_id=lead_id,
            emp_id=emp_id,
            action_type=action_type,
            activity_type_id=activity_type_id,
            details=details,
            old_value=old_val,
            new_value=new_val
        )
        db.session.add(log)
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"Error logging activity: {str(e)}")

def update_lead_service(lead_id, data, current_emp_id):
    """Updates a lead and logs status changes."""
    try:
        lead = Lead.query.get(lead_id)
        if not lead:
            return {"error": "Lead not found"}, 404

        old_status = lead.status_rel.status_name if lead.status_rel else None
        new_status_id = data.get('status_id')
        new_source_id = data.get('lead_source_id')

        # Update fields
        lead.name = data.get('name', lead.name)
        lead.lead_cat = data.get('lead_cat', lead.lead_cat)
        lead.email = data.get('email', lead.email)
        lead.mob_no = data.get('mob_no', lead.mob_no)
        lead.lead_source_id = new_source_id if new_source_id is not None else lead.lead_source_id
        lead.status_id = new_status_id if new_status_id is not None else lead.status_id
        lead.remarks = data.get('remarks', lead.remarks)
        lead.follow_up_date = data.get('follow_up_date', lead.follow_up_date)

        # Log status change if applicable
        if new_status_id and lead.status_id == new_status_id:
            new_status_obj = LeadsStatus.query.get(new_status_id)
            new_status_name = new_status_obj.status_name if new_status_obj else "Unknown"
            
            if old_status != new_status_name:
                log_lead_activity(
                    lead_id, 
                    current_emp_id, 
                    'Status Change', 
                    f'Status updated from {old_status} to {new_status_name}', 
                    old_status, 
                    new_status_name
                )
        
        # Log other updates if needed (e.g., Note Added)
        elif data.get('remarks') and data.get('remarks') != lead.remarks:
             log_lead_activity(lead_id, current_emp_id, 'Note Added', 'Remarks updated.')

        db.session.commit()
        return {"message": "Lead updated successfully"}, 200

    except Exception as e:
        db.session.rollback()
        return {"error": str(e)}, 500

def update_lead_status_service(lead_id, status_id, current_emp_id):
    """Specialized service only for updating lead status."""
    try:
        lead = Lead.query.get(lead_id)
        if not lead:
            return {"error": "Lead not found"}, 404

        old_status = lead.status_rel.status_name if lead.status_rel else None
        status_obj = LeadsStatus.query.get(status_id)
        if not status_obj:
            return {"error": "Invalid status ID"}, 400

        new_status = status_obj.status_name
        
        lead.status_id = status_id

        if old_status != new_status:
            log_lead_activity(
                lead_id, 
                current_emp_id, 
                'Status Change', 
                f'Status updated from {old_status} to {new_status}', 
                old_status, 
                new_status
            )
            db.session.commit()
            return {"message": "Status updated successfully"}, 200
        
        return {"message": "No status change detected"}, 200

    except Exception as e:
        db.session.rollback()
        return {"error": str(e)}, 500

def add_lead_note_service(lead_id, emp_id, details, activity_type_name="Note Added"):
    """Records a structured manual activity note and syncs basic remarks."""
    try:
        # 1. Record the note in activities
        log_lead_activity(
            lead_id=lead_id,
            emp_id=emp_id,
            action_type=activity_type_name,
            details=details
        )

        # 2. Sync the latest remark back to the main 'leads' table
        lead = Lead.query.get(lead_id)
        if lead:
            lead.remarks = details
            db.session.commit()

        return {"message": "Note recorded and synced successfully"}, 201

    except Exception as e:
        db.session.rollback()
        return {"error": str(e)}, 500

def get_lead_activities_service(lead_id):
    """Fetches activity timeline for a lead."""
    try:
        activities = LeadsActivityLog.query.filter_by(lead_id=lead_id).order_by(LeadsActivityLog.created_at.desc()).all()
        return [
            {
                "id": act.id,
                "action_type": act.action_type,
                "details": act.details,
                "old_value": act.old_value,
                "new_value": act.new_value,
                "created_at": act.created_at.strftime('%Y-%m-%d %H:%M:%S'),
                "emp_name": act.employee.name if act.employee else "Unknown"
            }
            for act in activities
        ], 200
    except Exception as e:
        return {"error": str(e)}, 500

def get_lead_statuses():
    """Fetches all active lead statuses."""
    try:
        statuses = LeadsStatus.query.filter_by(is_active=True).all()
        return [status.to_dict() for status in statuses], 200
    except Exception as e:
        return {"error": str(e)}, 500

def get_lead_sources():
    """Fetches all active lead sources."""
    try:
        sources = LeadsSource.query.filter_by(is_active=True).all()
        return [source.to_dict() for source in sources], 200
    except Exception as e:
        return {"error": str(e)}, 500

def get_activity_types_service():
    """Fetches structured activity types."""
    try:
        types = LeadsActivityType.query.all()
        return [{"id": t.id, "name": t.name} for t in types], 200
    except Exception as e:
        return {"error": str(e)}, 500

def get_pipeline_stages_service():
    """Fetches static pipeline stage configurations."""
    try:
        stages = LeadsStage.query.filter_by(is_active=True).order_by(LeadsStage.order_no).all()
        return [stage.to_dict() for stage in stages], 200
    except Exception as e:
        return {"error": str(e)}, 500

def advance_lead_stage_service(lead_id, stage_id, current_emp_id):
    try:
        lead = Lead.query.get(lead_id)
        if not lead:
            return {"error": "Lead not found"}, 404

        stage = LeadsStage.query.get(stage_id)
        if not stage:
            return {"error": "Invalid stage ID"}, 400

        old_stage = lead.stage.stage_name if lead.stage else "Unknown"
        lead.stage_id = stage_id
        
        # Auto-calculate follow_up_date
        lead.follow_up_date = datetime.now() + timedelta(days=stage.delay_days)

        log_lead_activity(
            lead_id, 
            current_emp_id, 
            'Stage Progressed', 
            f'Stage advanced from {old_stage} to {stage.stage_name}. Next action due in {stage.delay_days} days.', 
            old_stage, 
            stage.stage_name
        )
        
        db.session.commit()
        return {
            "message": "Stage advanced successfully", 
            "follow_up_date": lead.follow_up_date.strftime('%Y-%m-%d %H:%M:%S'),
            "stage_name": stage.stage_name
        }, 200

    except Exception as e:
        db.session.rollback()
        return {"error": str(e)}, 500